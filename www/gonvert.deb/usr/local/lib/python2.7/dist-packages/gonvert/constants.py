__pretty_app_name__ = "Gonvert"
__app_name__ = "gonvert"
__version__ = "1.1.5"
__build__ = 0
__app_magic__ = 0xdeadbeef

PROFILE_STARTUP = False
IS_MAEMO = True
